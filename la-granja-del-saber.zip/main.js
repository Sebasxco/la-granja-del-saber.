document.getElementById("startBtn").addEventListener("click", () => {
  const gameArea = document.getElementById("gameArea");
  const crops = ["🥕 Zanahoria", "🍅 Tomate", "🌽 Maíz", "🥬 Lechuga", "🍌 Plátano"];
  const crop = crops[Math.floor(Math.random() * crops.length)];
  gameArea.innerHTML = `<div class="text-2xl font-semibold mt-4">Has plantado: ${crop}</div>`;
});